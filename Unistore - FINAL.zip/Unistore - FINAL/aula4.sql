-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 22/09/2026 às 02:50
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `aula4`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `cadastro`
--

CREATE TABLE `cadastro` (
  `nome` varchar(50) NOT NULL,
  `email/tel` varchar(50) NOT NULL,
  `cpf` varchar(11) NOT NULL,
  `data_nasc` varchar(8) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `cep` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `cadastro`
--

INSERT INTO `cadastro` (`nome`, `email/tel`, `cpf`, `data_nasc`, `senha`, `cep`) VALUES
('Riana', 'rianacleysla@gmail.com', '$2y$10$PAhb', '2026-09-', '$2y$10$tWlkdDc5nRsTvkHpZmDDWe8OMr5zxJkyMwmAc2ToftaHWujkZezbG', '75620-00');

-- --------------------------------------------------------

--
-- Estrutura para tabela `carrinho`
--

CREATE TABLE `carrinho` (
  `id` int(10) UNSIGNED NOT NULL,
  `usuario_id` varchar(150) NOT NULL,
  `produto_id` int(10) UNSIGNED NOT NULL,
  `quantidade` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `adicionado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `carrinho`
--

INSERT INTO `carrinho` (`id`, `usuario_id`, `produto_id`, `quantidade`, `adicionado_em`) VALUES
(11, 'rianacleysla@gmail.com', 17, 2, '2026-09-22 00:46:51');

-- --------------------------------------------------------

--
-- Estrutura para tabela `forum_mensagens`
--

CREATE TABLE `forum_mensagens` (
  `id` int(10) UNSIGNED NOT NULL,
  `nome` varchar(80) NOT NULL,
  `mensagem` text NOT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `forum_mensagens`
--

INSERT INTO `forum_mensagens` (`id`, `nome`, `mensagem`, `criado_em`) VALUES
(3, 'Riana', 'Olá, gostaria de dizer que o meu abajur de flor é maravilhoso! Só comprem!', '2026-09-22 00:27:23');

-- --------------------------------------------------------

--
-- Estrutura para tabela `produtos`
--

CREATE TABLE `produtos` (
  `id` int(10) UNSIGNED NOT NULL,
  `nome` varchar(255) NOT NULL,
  `categoria` varchar(255) NOT NULL,
  `preco` varchar(255) NOT NULL,
  `imagem` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `produtos`
--

INSERT INTO `produtos` (`id`, `nome`, `categoria`, `preco`, `imagem`) VALUES
(14, 'Pulseira de botões', 'Acessórios', '15,00', 'produto_6ab1c98243e6a1.85443096.jpeg'),
(15, 'Pratos de frutas', 'Outros', '50,00', 'produto_6ab1c9bfbabb42.89903444.jpeg'),
(16, 'Xícara de gatinho', 'Outros', '35,00', 'produto_6ab1c9ede2e279.86498156.jpeg'),
(17, 'Abajur de flor', 'Outros', '78,00', 'produto_6ab1ca2c7011c7.12797884.jpeg'),
(18, 'Chaveiro de estrela', 'Outros', '20,00', 'produto_6ab1caf45cf662.67475596.jpeg'),
(19, 'Porta óculos', 'Outros', '80,00', 'produto_6ab1cb24d5f5b8.13428543.jpeg');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `cadastro`
--
ALTER TABLE `cadastro`
  ADD PRIMARY KEY (`senha`);

--
-- Índices de tabela `carrinho`
--
ALTER TABLE `carrinho`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_carrinho_produto` (`produto_id`),
  ADD KEY `idx_usuario` (`usuario_id`);

--
-- Índices de tabela `forum_mensagens`
--
ALTER TABLE `forum_mensagens`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `produtos`
--
ALTER TABLE `produtos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `carrinho`
--
ALTER TABLE `carrinho`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de tabela `forum_mensagens`
--
ALTER TABLE `forum_mensagens`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `produtos`
--
ALTER TABLE `produtos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `carrinho`
--
ALTER TABLE `carrinho`
  ADD CONSTRAINT `fk_carrinho_produto` FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
