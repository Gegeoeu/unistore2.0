<?php
session_start();
include __DIR__ . '/conexao.php';

/* =========================
   ESSA PÁGINA EXIGE LOGIN
========================= */

if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php?redirecionar=carrinho.php');
    exit;
}

$usuarioLogado = $_SESSION['usuario_id'];

/* =========================
   REMOVER ITEM DO CARRINHO
========================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remover'])) {

    $itemId = (int) $_POST['remover'];

    $stmtRemove = mysqli_prepare(
        $conexao,
        'DELETE FROM carrinho WHERE id = ? AND usuario_id = ?'
    );
    mysqli_stmt_bind_param($stmtRemove, 'is', $itemId, $usuarioLogado);
    mysqli_stmt_execute($stmtRemove);
    mysqli_stmt_close($stmtRemove);

    header('Location: carrinho.php');
    exit;
}

/* =========================
   BUSCAR ITENS DO CARRINHO
========================= */

$itens = [];

$stmtItens = mysqli_prepare(
    $conexao,
    "SELECT c.id, c.quantidade, p.nome, p.categoria, p.preco, p.imagem
     FROM carrinho c
     INNER JOIN produtos p ON p.id = c.produto_id
     WHERE c.usuario_id = ?
     ORDER BY c.adicionado_em ASC"
);

if ($stmtItens) {
    mysqli_stmt_bind_param($stmtItens, 's', $usuarioLogado);
    mysqli_stmt_execute($stmtItens);

    mysqli_stmt_bind_result(
        $stmtItens,
        $itemId,
        $itemQuantidade,
        $itemNome,
        $itemCategoria,
        $itemPreco,
        $itemImagem
    );

    while (mysqli_stmt_fetch($stmtItens)) {
        $itens[] = [
            'id' => $itemId,
            'quantidade' => $itemQuantidade,
            'nome' => $itemNome,
            'categoria' => $itemCategoria,
            'preco' => $itemPreco,
            'imagem' => $itemImagem,
        ];
    }

    mysqli_stmt_close($stmtItens);
}

$total = 0;

foreach ($itens as $item) {
    $total += ((float) $item['preco']) * ((int) $item['quantidade']);
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrinho | Unistore</title>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@500;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; }
        body { margin: 0; min-height: 100vh; padding: 24px; background: #fff7fb; color: #8b3a62; font-family: 'Poppins', sans-serif; }
        .pagina { width: min(760px, 100%); margin: 0 auto; padding: 42px 30px; border: 1px solid #f8c8dc; border-radius: 22px; background: #fff; box-shadow: 0 10px 25px rgba(139, 58, 98, .14); }
        .cabecalho { text-align: center; }
        .logo { width: 110px; height: 110px; object-fit: contain; }
        h1 { margin: 8px 0 10px; font-family: 'Cinzel', serif; }
        p { color: #6a4251; }

        .lista { margin-top: 30px; display: grid; gap: 16px; }
        .item {
            display: grid;
            grid-template-columns: 90px 1fr auto;
            gap: 16px;
            align-items: center;
            padding: 14px;
            border: 1px solid #f8c8dc;
            border-radius: 16px;
            background: #fffafc;
        }
        .item img { width: 90px; height: 90px; object-fit: cover; border-radius: 12px; background: #ffe4f3; }
        .item-info h2 { margin: 0 0 4px; font-size: 17px; font-family: 'Poppins', sans-serif; }
        .item-info .categoria { font-size: 13px; color: #b05c85; margin-bottom: 6px; }
        .item-info .preco-unit { font-size: 13px; color: #6a4251; }
        .item-info .subtotal { margin-top: 4px; font-weight: 700; color: #d63384; }
        .item-acoes { display: flex; flex-direction: column; align-items: flex-end; gap: 8px; }
        .quantidade { font-size: 13px; background: #ffe4f3; color: #8b3a62; padding: 4px 10px; border-radius: 12px; font-weight: 600; }
        .btn-remover { border: none; background: #fce4ef; color: #a12626; padding: 8px 14px; border-radius: 20px; font-weight: 600; font-size: 13px; cursor: pointer; transition: 0.3s; font-family: inherit; }
        .btn-remover:hover { background: #ffd9d9; }

        .resumo { margin-top: 28px; padding-top: 20px; border-top: 1px dashed #f8c8dc; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; }
        .resumo .total { font-size: 22px; font-weight: 700; color: #1a1a1a; }

        .vazio { text-align: center; padding: 30px 0; color: #8b3a62; font-weight: 600; }

        .acoes { display: flex; justify-content: center; gap: 12px; flex-wrap: wrap; margin-top: 28px; }
        .acoes a { padding: 12px 20px; border-radius: 24px; text-decoration: none; font-weight: 600; }
        .principal { color: #fff; background: linear-gradient(135deg, #ff4fa3, #ff85c2, #ffd6a5); }
        .secundario { color: #8b3a62; background: #fce4ef; }

        @media (max-width: 560px) {
            .item { grid-template-columns: 70px 1fr; }
            .item-acoes { grid-column: 1 / -1; flex-direction: row; justify-content: space-between; align-items: center; }
        }
    </style>
</head>
<body>
    <main class="pagina">

        <div class="cabecalho">
            <img class="logo" src="logo.png" alt="Logo Unistore">
            <h1>Seu carrinho</h1>
            <?php if (empty($itens)): ?>
                <p>Seu carrinho ainda está vazio.</p>
            <?php else: ?>
                <p>Confira os produtos que você adicionou.</p>
            <?php endif; ?>
        </div>

        <?php if (empty($itens)): ?>

            <div class="vazio">🛒 Nenhum produto no carrinho por enquanto.</div>

        <?php else: ?>

            <div class="lista">
                <?php foreach ($itens as $item): ?>
                    <?php
                    $imagem = !empty($item['imagem']) ? 'uploads/' . $item['imagem'] : 'logo.png';
                    $subtotal = ((float) $item['preco']) * ((int) $item['quantidade']);
                    ?>
                    <div class="item">
                        <img src="<?php echo htmlspecialchars($imagem); ?>" alt="<?php echo htmlspecialchars($item['nome']); ?>">

                        <div class="item-info">
                            <h2><?php echo htmlspecialchars($item['nome']); ?></h2>
                            <div class="categoria"><?php echo htmlspecialchars($item['categoria']); ?></div>
                            <div class="preco-unit">R$ <?php echo htmlspecialchars($item['preco']); ?> cada</div>
                            <div class="subtotal">Subtotal: R$ <?php echo number_format($subtotal, 2, ',', '.'); ?></div>
                        </div>

                        <div class="item-acoes">
                            <span class="quantidade">Qtd: <?php echo (int) $item['quantidade']; ?></span>
                            <form method="post" action="carrinho.php">
                                <input type="hidden" name="remover" value="<?php echo (int) $item['id']; ?>">
                                <button type="submit" class="btn-remover">✕ Remover</button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="resumo">
                <span>Total (<?php echo count($itens); ?> item<?php echo count($itens) > 1 ? 's' : ''; ?>)</span>
                <span class="total">R$ <?php echo number_format($total, 2, ',', '.'); ?></span>
            </div>

        <?php endif; ?>

        <div class="acoes">
            <a class="principal" href="produtos.php">Continuar comprando</a>
            <a class="secundario" href="inicio.php">Voltar ao início</a>
        </div>

    </main>
</body>
</html>
