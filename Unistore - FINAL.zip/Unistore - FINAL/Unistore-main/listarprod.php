<?php
session_start();
require __DIR__ . '/conexao.php';

$carrinhoQtd = 0;
$usuarioLogado = $_SESSION['usuario_id'] ?? null;

if ($usuarioLogado) {
    $stmtQtd = mysqli_prepare(
        $conexao,
        'SELECT COALESCE(SUM(quantidade), 0) FROM carrinho WHERE usuario_id = ?'
    );
    mysqli_stmt_bind_param($stmtQtd, 's', $usuarioLogado);
    mysqli_stmt_execute($stmtQtd);
    mysqli_stmt_bind_result($stmtQtd, $carrinhoQtd);
    mysqli_stmt_fetch($stmtQtd);
    mysqli_stmt_close($stmtQtd);
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Entrar na Unistore</title>
    <style>
        * { box-sizing: border-box; font-family: 'Segoe UI', sans-serif; }
        body { margin: 0; min-height: 100vh; display: grid; place-items: center; padding: 24px; background: linear-gradient(135deg, #ffe6f2, #ffd6eb); color: #8b3a62; }
        .container { width: min(760px, 100%); padding: 38px; border-radius: 24px; background: #fff; box-shadow: 0 12px 30px rgba(91, 32, 61, .16); text-align: center; }
        .logo { width: 150px; max-width: 70%; margin-bottom: 12px; }
        h1 { margin: 0 0 10px; font-size: clamp(28px, 5vw, 42px); }
        .intro { margin: 0 auto 28px; color: #6a4251; }
        .opcoes { display: grid; grid-template-columns: repeat(2, 1fr); gap: 18px; }
        .opcao { padding: 26px 20px; border: 1px solid #f8c8dc; border-radius: 16px; background: #fffafc; }
        .opcao h2 { margin: 0 0 8px; font-size: 22px; }
        .opcao p { min-height: 48px; margin: 0 0 20px; color: #6a4251; }
        .botao { display: inline-block; width: 100%; padding: 13px 18px; border-radius: 24px; background: #d63384; color: #fff; text-decoration: none; font-weight: bold; }
        .botao.secundario { background: #fce4ef; color: #8b3a62; }
        @media (max-width: 600px) { .container { padding: 28px 20px; } .opcoes { grid-template-columns: 1fr; } }

        /* ÍCONE DO CARRINHO NO CANTO SUPERIOR */
        .carrinho-flutuante {
            position: fixed;
            top: 20px;
            right: 20px;
            width: 54px;
            height: 54px;
            border-radius: 50%;
            background: #fff;
            border: 1px solid #f8c8dc;
            box-shadow: 0 8px 20px rgba(139, 58, 98, .18);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            text-decoration: none;
            z-index: 20;
            transition: 0.3s;
        }
        .carrinho-flutuante:hover { transform: translateY(-3px); border-color: #d63384; }
        .badge-carrinho {
            position: absolute;
            top: -6px;
            right: -6px;
            min-width: 20px;
            height: 20px;
            padding: 0 4px;
            border-radius: 10px;
            background: #d63384;
            color: #fff;
            font-size: 12px;
            font-weight: bold;
            display: flex;
            align-items: center;
            justify-content: center;
        }
    </style>
</head>
<body>
    <a href="carrinho.php" class="carrinho-flutuante" aria-label="Abrir carrinho">
        🛒
        <?php if ($carrinhoQtd > 0): ?>
            <span class="badge-carrinho"><?php echo (int) $carrinhoQtd; ?></span>
        <?php endif; ?>
    </a>

    <main class="container">
        <img class="logo" src="logo.png" alt="Logo Unistore">
        <h1>Como você quer entrar?</h1>
        <p class="intro">Escolha seu caminho para continuar na Unistore.</p>
        <section class="opcoes">
            <article class="opcao">
                <h2>Cliente</h2>
                <p>Veja os produtos disponíveis no catálogo.</p>
                <a class="botao" href="produtos.php">Ver produtos</a>
            </article>
            <article class="opcao">
                <h2>Vendedor</h2>
                <p>Acesse sua conta para cadastrar produtos.</p>
                <a class="botao secundario" href="login.php">Entrar como vendedor</a>
            </article>
        </section>
    </main>
</body>
</html>
