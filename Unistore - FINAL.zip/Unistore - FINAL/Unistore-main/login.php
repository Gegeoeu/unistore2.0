<?php

session_start();

include __DIR__ . "/conexao.php";

$msg = "";

/* =========================
   PARA ONDE VOLTAR APÓS O LOGIN
========================= */

$destinosPermitidos = ['painel.php', 'produtos.php', 'carrinho.php'];
$redirecionar = $_POST['redirecionar'] ?? $_GET['redirecionar'] ?? 'painel.php';

if (!in_array($redirecionar, $destinosPermitidos, true)) {
    $redirecionar = 'painel.php';
}

if(isset($_POST['login'])) {

    $email_tel = trim($_POST['email_tel'] ?? '');
    $senha = $_POST['senha'] ?? '';
    $identificador = filter_var($email_tel, FILTER_VALIDATE_EMAIL)
        ? strtolower($email_tel)
        : preg_replace('/[^0-9]/', '', $email_tel);

    $stmt = mysqli_prepare(
        $conexao,
        "SELECT nome, `email/tel`, senha
         FROM cadastro
         WHERE LOWER(TRIM(`email/tel`)) = LOWER(?)
            OR REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(TRIM(`email/tel`), '(', ''), ')', ''), ' ', ''), '-', ''), '+', '') = ?
         LIMIT 1"
    );

    if (!$stmt) {
        $msg = "Não foi possível consultar o cadastro. Verifique a conexão com o banco.";
    } else {
        mysqli_stmt_bind_param($stmt, "ss", $identificador, $identificador);

        if (!mysqli_stmt_execute($stmt)) {
            $msg = "Não foi possível consultar o cadastro. Verifique a conexão com o banco.";
            $dados = null;
        } else {
            mysqli_stmt_bind_result($stmt, $nome, $emailCadastrado, $senhaCadastrada);
            $dados = mysqli_stmt_fetch($stmt) ? [
                'nome' => $nome,
                'email/tel' => $emailCadastrado,
                'senha' => $senhaCadastrada
            ] : null;
        }

        if ($dados && is_string($dados['senha']) && password_verify($senha, $dados['senha'])) {

            $_SESSION['usuario_id'] = $dados['email/tel'];
            $_SESSION['usuario_nome'] = $dados['nome'];

            header("Location: " . $redirecionar);
            exit;

        } elseif ($dados) {
            $msg = strlen((string) $dados['senha']) < 60
                ? "Este cadastro possui uma senha antiga inválida. Faça um novo cadastro."
                : "Senha incorreta.";
        } elseif (empty($msg)) {
            $msg = "Usuário não encontrado.";
        }

        mysqli_stmt_close($stmt);
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login</title>

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Segoe UI', sans-serif;
}

body{
    background: linear-gradient(135deg, #ffe6f2, #ffd6eb);
    display:flex;
    justify-content:center;
    align-items:center;
    min-height:100vh;
}

.container{
    width:400px;
    background:white;
    padding:35px;
    border-radius:20px;
    box-shadow:0 10px 25px rgba(0,0,0,0.15);
}

.logo{
    display:block;
    margin:0 auto 15px auto;
    width:300px; /* ajuste o tamanho se desejar */
    height:auto;
}

h2{
    text-align:center;
    color:#8b3a62;
    margin-bottom:25px;
}

form{
    display:flex;
    flex-direction:column;
}

label{
    margin-top:12px;
    margin-bottom:5px;
    color:#8b3a62;
    font-weight:600;
}

input{
    padding:12px;
    border-radius:12px;
    border:1px solid #f8c8dc;
    outline:none;
    transition:0.3s;
}

input:focus{
    border-color:#d63384;
    box-shadow:0 0 8px rgba(214,51,132,0.3);
}

button{
    margin-top:25px;
    padding:12px;
    border:none;
    border-radius:25px;
    background:#d63384;
    color:white;
    font-size:16px;
    font-weight:bold;
    cursor:pointer;
    transition:0.3s;
}

button:hover{
    background:#c2186a;
    transform:scale(1.03);
}

.mensagem{
    margin-top:15px;
    text-align:center;
    font-weight:bold;
    color:#8b3a62;
}

.footer-link{
    margin-top:20px;
    text-align:center;
    color:#8b3a62;
    font-size:14px;
}

.footer-link a{
    color:#d63384;
    font-weight:bold;
    text-decoration:none;
    transition:0.3s;
}

.footer-link a:hover{
    color:#c2186a;
    text-decoration:underline;
}

.esqueci-senha{
    margin-top:12px;
    text-align:center;
}

.esqueci-senha a{
    color:#8b3a62;
    font-size:14px;
    text-decoration:none;
    transition:0.3s;
    font-weight: bold;
}

.esqueci-senha a:hover{
    color:#d63384;
    text-decoration:underline;
}

</style>
</head>

<body>

<div class="container">

   <form method="POST">

    <input type="hidden" name="redirecionar" value="<?php echo htmlspecialchars($redirecionar); ?>">

    <img src="logo.png" alt="Logo" class="logo">

    <h2>LOGIN</h2>

    <label>E-mail ou telefone:</label>
    <input
        type="text"
        name="email_tel"
        required
    >

    <label>Senha:</label>
    <input
        type="password"
        name="senha"
        required
    >

    <button type="submit" name="login">
        ENTRAR
    </button>

    <?php
    if(!empty($msg)){
        echo "<div class='mensagem'>$msg</div>";
    } elseif ($redirecionar !== 'painel.php' && $_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo "<div class='mensagem'>Faça login para continuar a compra.</div>";
    }
    ?>

    
    <p class="esqueci-senha">
    <a href="alterarsenha.php">Esqueci minha senha</a>
    </p>

    <p class="footer-link">
    Não tem conta?
    <a href="cadastro.php">Cadastre-se</a>
    </p>


</form>

</div>

</body>
</html>