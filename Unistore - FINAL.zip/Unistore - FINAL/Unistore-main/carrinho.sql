-- ==========================================================
-- Banco: aula4
-- ==========================================================
-- PASSO 1 (obrigatório): sua tabela "produtos" hoje só tem
-- nome, categoria, preco e imagem, sem um id próprio. Como
-- agora vamos referenciar produtos pelo id (e não pelo nome,
-- que pode se repetir ou ter acentuação diferente), rode:

ALTER TABLE produtos
    ADD COLUMN id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY FIRST;

-- Isso numera automaticamente os produtos que já existem na
-- tabela (1, 2, 3...) sem apagar nada.

-- ==========================================================
-- PASSO 2: tabela nova do carrinho
-- ==========================================================
-- Agora que o cliente precisa fazer login para comprar, o
-- carrinho é vinculado à conta dele (usuario_id = o mesmo
-- valor salvo em `email/tel` na tabela cadastro / na sessão
-- de login), e não mais a uma sessão anônima do navegador.

CREATE TABLE IF NOT EXISTS carrinho (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    usuario_id    VARCHAR(150) NOT NULL,
    produto_id    INT UNSIGNED NOT NULL,
    quantidade    INT UNSIGNED NOT NULL DEFAULT 1,
    adicionado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_carrinho_produto
        FOREIGN KEY (produto_id) REFERENCES produtos(id)
        ON DELETE CASCADE,
    KEY idx_usuario (usuario_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
