<?php
session_start();
include __DIR__ . '/conexao.php';

// Pega o nome do produto vindo pela URL
$nomeProduto = isset($_GET['nome']) ? trim($_GET['nome']) : '';

$produto = null;

if ($nomeProduto !== '') {
    // Busca o produto pelo NOME na tabela produtos
    $stmt = mysqli_prepare($conexao, "SELECT * FROM produtos WHERE nome = ? LIMIT 1");
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "s", $nomeProduto);
        mysqli_stmt_execute($stmt);
        $resultado = mysqli_stmt_get_result($stmt);
        $produto = mysqli_fetch_assoc($resultado);
        mysqli_stmt_close($stmt);
    }
}

// Descobre o caminho web da pasta para as imagens
$diretorioWeb = dirname($_SERVER['SCRIPT_NAME']);
$diretorioWeb = ($diretorioWeb === '/' || $diretorioWeb === '\\') ? '' : rtrim(str_replace('\\', '/', $diretorioWeb), '/');

// Mensagens de ação
$mensagemSucesso = '';
$mensagemErro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $produto) {
    $quantidade = isset($_POST['quantidade']) ? max(1, (int)$_POST['quantidade']) : 1;

    // Se clicou em ADICIONAR AO CARRINHO
    if (isset($_POST['adicionar_carrinho'])) {
        // Exige login para adicionar ao carrinho
        if (!isset($_SESSION['usuario_id'])) {
            header('Location: login.php?redirecionar=' . urlencode($_SERVER['REQUEST_URI']));
            exit;
        }

        $usuarioLogado = $_SESSION['usuario_id'];
        $produtoId = $produto['id'] ?? null;

        // Se sua tabela produtos não tiver ID numérico, busca ou usa o ID existente
        if (!$produtoId) {
            // Caso sua tabela carrinho use o ID, assegura que temos o id do produto
            $resId = mysqli_query($conexao, "SELECT id FROM produtos WHERE nome = '" . mysqli_real_escape_string($conexao, $produto['nome']) . "' LIMIT 1");
            if ($rowId = mysqli_fetch_assoc($resId)) {
                $produtoId = $rowId['id'];
            }
        }

        if ($produtoId) {
            // Verifica se o item já está no carrinho do usuário
            $stmtCheck = mysqli_prepare($conexao, "SELECT id, quantidade FROM carrinho WHERE usuario_id = ? AND produto_id = ?");
            mysqli_stmt_bind_param($stmtCheck, 'si', $usuarioLogado, $produtoId);
            mysqli_stmt_execute($stmtCheck);
            $resCheck = mysqli_stmt_get_result($stmtCheck);
            $itemExistente = mysqli_fetch_assoc($resCheck);
            mysqli_stmt_close($stmtCheck);

            if ($itemExistente) {
                // Se já existe, atualiza a quantidade somando
                $novaQtd = $itemExistente['quantidade'] + $quantidade;
                $stmtUp = mysqli_prepare($conexao, "UPDATE carrinho SET quantidade = ? WHERE id = ?");
                mysqli_stmt_bind_param($stmtUp, 'ii', $novaQtd, $itemExistente['id']);
                mysqli_stmt_execute($stmtUp);
                mysqli_stmt_close($stmtUp);
            } else {
                // Se não existe, insere no carrinho
                $stmtAdd = mysqli_prepare($conexao, "INSERT INTO carrinho (usuario_id, produto_id, quantidade) VALUES (?, ?, ?)");
                mysqli_stmt_bind_param($stmtAdd, 'sii', $usuarioLogado, $produtoId, $quantidade);
                mysqli_stmt_execute($stmtAdd);
                mysqli_stmt_close($stmtAdd);
            }

            $mensagemSucesso = '🛒 Produto adicionado ao carrinho com sucesso!';
        } else {
            $mensagemErro = 'Não foi possível identificar o código do produto no banco.';
        }

    // Se clicou em COMPRAR direto
    } elseif (isset($_POST['comprar_direto'])) {
        $mensagemSucesso = '🎉 Pedido realizado com sucesso! Obrigado pela sua compra.';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $produto ? htmlspecialchars($produto['nome']) . ' - Comprar' : 'Produto não encontrado'; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@500;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0;
            background: #fff7fb;
            color: #8b3a62;
            padding: 112px 20px 40px;
            font-family: 'Poppins', sans-serif;
        }
        header {
            position: fixed;
            top: 0;
            left: 0;
            z-index: 10;
            width: 100%;
            min-height: 80px;
            padding: 0 50px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 24px;
            background: rgba(255, 214, 234, .9);
            backdrop-filter: blur(14px);
            border-bottom: 1px solid rgba(255, 255, 255, .7);
        }
        .marca { display: flex; align-items: center; gap: 10px; font-family: 'Cinzel', serif; font-size: 30px; font-weight: 700; letter-spacing: 2px; text-decoration: none; color: #8b3a62; }
        .marca img { width: 92px; height: 92px; object-fit: contain; }
        nav { display: flex; gap: 24px; }
        nav a { color: #8b3a62; text-decoration: none; font-weight: 600; }
        nav a:hover { color: #d63384; }
        .acoes { display: flex; gap: 10px; align-items: center; }
        .topo-btn { padding: 11px 18px; border-radius: 30px; text-decoration: none; font-size: 14px; font-weight: 600; }
        .topo-carrinho { color: #8b3a62; background: #fff; border: 1px solid #c76b96; transition: 0.2s; }
        .topo-carrinho:hover { background: #ffe3ee; }

        .container {
            max-width: 950px;
            margin: 0 auto;
            background: #fff;
            border-radius: 20px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.08);
            padding: 40px;
        }

        .detalhes-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 40px;
            align-items: stretch;
        }

        .foto-bloco {
            display: flex;
            width: 100%;
            height: 100%;
            align-items: center;
            justify-content: center;
        }

        .foto-bloco img {
            width: 100%;
            height: 100%;
            min-height: 440px;
            max-height: 520px;
            object-fit: cover;
            border-radius: 16px;
            border: 1px solid #f8c8dc;
            background: #fffafc;
            padding: 0;
            display: block;
        }

        .info-bloco {
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .info-bloco h1 {
            margin: 0 0 8px;
            font-size: 32px;
            color: #8b3a62;
        }
        .categoria-tag {
            display: inline-block;
            align-self: flex-start;
            background: #ffe3ee;
            color: #b8256d;
            padding: 4px 14px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 12px;
        }
        .preco {
            font-size: 34px;
            font-weight: 700;
            color: #d63384;
            margin: 10px 0 20px;
        }
        .descricao {
            font-size: 15px;
            line-height: 1.6;
            color: #555;
            margin-bottom: 25px;
        }

        .form-compra {
            background: #fffafc;
            border: 1px solid #f8c8dc;
            border-radius: 16px;
            padding: 24px;
            display: flex;
            flex-direction: column;
            gap: 14px;
        }
        .form-compra h3 {
            margin: 0 0 4px;
            font-size: 18px;
        }
        .form-compra label {
            font-size: 13px;
            font-weight: 600;
            color: #6a4251;
        }
        .form-compra input[type="number"] {
            width: 100%;
            padding: 12px 14px;
            border: 1px solid #f8c8dc;
            border-radius: 10px;
            font-family: inherit;
            font-size: 15px;
        }

        .botoes-compra {
            display: flex;
            flex-direction: column;
            gap: 10px;
            margin-top: 6px;
        }

        .btn-comprar-principal {
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 25px;
            background: #d63384;
            color: #fff;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.2s;
        }
        .btn-comprar-principal:hover {
            background: #b8256d;
        }

        .btn-carrinho {
            width: 100%;
            padding: 13px;
            border: 2px solid #d63384;
            border-radius: 25px;
            background: #fff;
            color: #d63384;
            font-size: 15px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.2s;
        }
        .btn-carrinho:hover {
            background: #ffeef6;
        }

        .alerta-sucesso {
            background: #e6f7ed;
            color: #176b3a;
            padding: 16px;
            border-radius: 12px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: 600;
        }
        .alerta-erro {
            background: #ffe5e5;
            color: #a12626;
            padding: 16px;
            border-radius: 12px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: 600;
        }
        .btn-voltar {
            display: inline-block;
            margin-top: 25px;
            color: #8b3a62;
            text-decoration: none;
            font-weight: 600;
        }
        .btn-voltar:hover {
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .detalhes-container { grid-template-columns: 1fr; }
            .foto-bloco img { min-height: 280px; }
            body { padding-top: 94px; }
        }
    </style>
</head>
<body>

    <header>
        <a class="marca" href="inicio.php">
            <img src="<?php echo $diretorioWeb; ?>/logo.png" alt="Logo Unistore">
            <span>Unistore</span>
        </a>
        <nav>
            <a href="inicio.php">Início</a>
            <a href="produtos.php#catalogo">Produtos</a>
            <a href="produtos.php#forum">Fórum</a>
        </nav>
        <div class="acoes">
            <a class="topo-btn topo-carrinho" href="carrinho.php">🛒 Carrinho</a>
        </div>
    </header>

    <div class="container">
        <?php if ($mensagemSucesso !== ''): ?>
            <div class="alerta-sucesso">
                <?php echo htmlspecialchars($mensagemSucesso); ?>
            </div>
        <?php endif; ?>

        <?php if ($mensagemErro !== ''): ?>
            <div class="alerta-erro">
                <?php echo htmlspecialchars($mensagemErro); ?>
            </div>
        <?php endif; ?>

        <?php if (!$produto): ?>
            <h2 style="text-align: center;">Produto não encontrado!</h2>
            <p style="text-align: center;">O produto selecionado não existe ou foi removido.</p>
            <div style="text-align: center;">
                <a class="btn-voltar" href="produtos.php">← Voltar para o catálogo</a>
            </div>
        <?php else: ?>
            <?php 
                $nomeFoto = trim($produto['imagem'] ?? '');
                $arquivoLimpo = basename(str_replace('\\', '/', $nomeFoto));
                $caminhoFisico = __DIR__ . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . $arquivoLimpo;

                if (!empty($arquivoLimpo) && file_exists($caminhoFisico)) {
                    $srcImagem = $diretorioWeb . '/uploads/' . $arquivoLimpo;
                } else {
                    $srcImagem = $diretorioWeb . '/logo.png';
                }
            ?>
            <div class="detalhes-container">
                <div class="foto-bloco">
                    <img src="<?php echo htmlspecialchars($srcImagem); ?>" alt="<?php echo htmlspecialchars($produto['nome']); ?>">
                </div>

                <div class="info-bloco">
                    <span class="categoria-tag"><?php echo htmlspecialchars($produto['categoria']); ?></span>
                    <h1><?php echo htmlspecialchars($produto['nome']); ?></h1>
                    <div class="preco">R$ <?php echo htmlspecialchars($produto['preco']); ?></div>

                    <?php if (!empty($produto['descricao'])): ?>
                        <p class="descricao"><?php echo nl2br(htmlspecialchars($produto['descricao'])); ?></p>
                    <?php endif; ?>

                    <form class="form-compra" method="post">
                        <h3>Detalhes da Compra</h3>
                        
                        <label for="qtd">Quantidade:</label>
                        <input type="number" id="qtd" name="quantidade" value="1" min="1" max="99" required>

                        <div class="botoes-compra">
                            <button type="submit" name="comprar_direto" class="btn-comprar-principal">COMPRAR</button>
                            <button type="submit" name="adicionar_carrinho" class="btn-carrinho">🛒 ADICIONAR AO CARRINHO</button>
                        </div>
                    </form>

                    <a class="btn-voltar" href="produtos.php">← Continuar comprando</a>
                </div>
            </div>
        <?php endif; ?>
    </div>

</body>
</html>