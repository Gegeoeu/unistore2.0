<?php
include __DIR__ . '/conexao.php';

$forumCriado = mysqli_query($conexao, "
    CREATE TABLE IF NOT EXISTS forum_mensagens (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        nome VARCHAR(80) NOT NULL,
        mensagem TEXT NOT NULL,
        criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

$forumMensagem = '';
$forumClasse = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['enviar_mensagem'])) {
    $nome = trim($_POST['nome'] ?? '');
    $mensagem = trim($_POST['mensagem'] ?? '');

    if ($nome === '' || $mensagem === '') {
        $forumMensagem = 'Preencha seu nome e escreva uma mensagem.';
        $forumClasse = 'erro';
    } elseif (strlen($nome) > 80) {
        $forumMensagem = 'O nome deve ter no máximo 80 caracteres.';
        $forumClasse = 'erro';
    } else {
        $stmtForum = mysqli_prepare($conexao, 'INSERT INTO forum_mensagens (nome, mensagem) VALUES (?, ?)');

        if ($stmtForum) {
            mysqli_stmt_bind_param($stmtForum, 'ss', $nome, $mensagem);
            $forumClasse = mysqli_stmt_execute($stmtForum) ? 'sucesso' : 'erro';
            $forumMensagem = $forumClasse === 'sucesso' ? 'Mensagem enviada!' : 'Não foi possível enviar a mensagem.';
            mysqli_stmt_close($stmtForum);
        } else {
            $forumMensagem = 'Não foi possível preparar a mensagem.';
            $forumClasse = 'erro';
        }
    }
}

$resultadoProdutos = mysqli_query($conexao, 'SELECT * FROM produtos ORDER BY nome ASC');
$produtos = $resultadoProdutos ? mysqli_fetch_all($resultadoProdutos, MYSQLI_ASSOC) : [];
$resultadoForum = mysqli_query($conexao, 'SELECT nome, mensagem, criado_em FROM forum_mensagens ORDER BY criado_em ASC, id ASC');
$mensagens = $resultadoForum ? mysqli_fetch_all($resultadoForum, MYSQLI_ASSOC) : [];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produtos</title>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@500;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0;
            background: #fff7fb;
            color: #8b3a62;
            padding: 112px 20px 40px;
            font-family: 'Poppins', sans-serif;
        }
        header {
            position: fixed;
            top: 0;
            left: 0;
            z-index: 10;
            width: 100%;
            min-height: 80px;
            padding: 0 50px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 24px;
            background: rgba(255, 214, 234, .9);
            backdrop-filter: blur(14px);
            border-bottom: 1px solid rgba(255, 255, 255, .7);
        }
        .marca { display: flex; align-items: center; gap: 10px; font-family: 'Cinzel', serif; font-size: 30px; font-weight: 700; letter-spacing: 2px; white-space: nowrap; }
        .marca img { width: 92px; height: 92px; object-fit: contain; }
        nav { display: flex; gap: 24px; }
        nav a { color: #8b3a62; text-decoration: none; font-weight: 600; }
        nav a:hover { color: #d63384; }
        .acoes { display: flex; gap: 10px; align-items: center; }
        .topo-btn { padding: 11px 18px; border-radius: 30px; text-decoration: none; font-size: 14px; font-weight: 600; }
        .topo-login { color: #8b3a62; background: #fff; border: 1px solid #c76b96; }
        .topo-vendedor { color: #fff; background: linear-gradient(135deg, #ff4fa3, #ff85c2, #ffd6a5); box-shadow: 0 5px 14px rgba(255, 79, 163, .25); }
        .topo-carrinho { color: #8b3a62; background: #fff; border: 1px solid #c76b96; }
        .topo-btn:hover { transform: translateY(-2px); }
        header + .container { max-width: 1180px; }
        .subtitulo { margin: -12px 0 28px; text-align: center; color: #6a4251; }
        .bloco-titulo { margin: 0 0 18px; font-family: 'Cinzel', serif; font-size: 24px; }
        .secao-intro, .fala-texto, .empty, .categoria, .preco, .nome { font-family: 'Poppins', sans-serif; }
        @media (max-width: 900px) { header { padding: 0 24px; } nav { display: none; } }
        @media (max-width: 560px) { header { min-height: 70px; padding: 0 16px; } .marca { font-size: 21px; } .marca img { width: 62px; height: 62px; } .topo-login { display: none; } .topo-vendedor { display: none; } .topo-carrinho { padding: 10px 12px; } body { padding-top: 94px; } }
        .container {
            max-width: 1100px;
            margin: 0 auto;
            background: #fff;
            border-radius: 20px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
            padding: 30px;
        }
        h1 { margin-top: 0; text-align: center; }
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            margin-top: 25px;
        }
        .card {
            background: #fffafc;
            border: 1px solid #f8c8dc;
            border-radius: 16px;
            padding: 15px;
        }
        .card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 12px;
            display: block;
            background: #fce4ef;
        }
        .nome { font-weight: bold; margin: 12px 0 6px; }
        .categoria { color: #a14d78; font-size: 14px; }
        .preco { margin-top: 10px; font-size: 22px; font-weight: bold; }
        .empty { text-align: center; color: #8b3a62; font-weight: 600; }
        .layout { display: grid; grid-template-columns: minmax(260px, .8fr) minmax(0, 1.8fr); gap: 24px; align-items: start; }
        .produtos-bloco, .secao { padding: 24px; border: 1px solid #f8c8dc; border-radius: 16px; background: #fffafc; }
        .secao { margin: 0; }
        .secao h2 { margin: 0 0 8px; }
        .secao-intro { margin: 0 0 18px; color: #6a4251; }
        .forum-form { display: grid; gap: 10px; margin-bottom: 22px; }
        .forum-form input, .forum-form textarea { width: 100%; padding: 12px; border: 1px solid #f8c8dc; border-radius: 10px; font: inherit; }
        .forum-form textarea { min-height: 90px; resize: vertical; }
        .forum-form button { width: fit-content; padding: 12px 20px; border: 0; border-radius: 22px; background: #d63384; color: #fff; font-weight: bold; cursor: pointer; }
        .mensagem-status { margin: 0 0 16px; padding: 10px 12px; border-radius: 10px; }
        .sucesso { background: #e6f7ed; color: #176b3a; }
        .erro { background: #ffe5e5; color: #a12626; }
        .chat { display: grid; gap: 12px; }
        .fala { padding: 14px; border: 1px solid #f8c8dc; border-radius: 14px; background: #fffafc; }
        .fala-cabecalho { display: flex; justify-content: space-between; gap: 12px; flex-wrap: wrap; font-size: 14px; }
        .fala-nome { font-weight: bold; }
        .fala-hora { color: #a14d78; }
        .fala-texto { margin: 8px 0 0; color: #4d3440; white-space: pre-wrap; overflow-wrap: anywhere; }
        @media (max-width: 800px) { .layout { grid-template-columns: 1fr; } }
        a.btn {
            display: inline-block;
            margin-top: 20px;
            color: #8b3a62;
            text-decoration: none;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <header>
        <a class="marca" href="inicio.php">
            <img src="logo.png" alt="Logo Unistore">
            <span>Unistore</span>
        </a>
        <nav>
            <a href="inicio.php">Início</a>
            <a href="#catalogo">Produtos</a>
            <a href="#forum">Fórum</a>
        </nav>
        <div class="acoes">
            <a class="topo-btn topo-login" href="login.php">Login</a>
            <a class="topo-btn topo-vendedor" href="listarprod.php">Entrar</a>
            <a class="topo-btn topo-carrinho" href="carrinho.php" aria-label="Abrir carrinho">🛒 Carrinho</a>
        </div>
    </header>
    <div class="container">
        <h1>Produtos cadastrados</h1>
        <p class="subtitulo">Descubra peças exclusivas e converse com a nossa comunidade.</p>

        <div class="layout">
            <section class="secao" id="forum">
            <h2>Fórum da comunidade</h2>
            <p class="secao-intro">Converse com outras pessoas e responda às mensagens da comunidade.</p>

            <?php if ($forumMensagem !== ''): ?>
                <p class="mensagem-status <?php echo $forumClasse; ?>"><?php echo htmlspecialchars($forumMensagem); ?></p>
            <?php endif; ?>

            <form class="forum-form" method="post" action="produtos.php#forum">
                <input type="text" name="nome" maxlength="80" placeholder="Seu nome" required>
                <textarea name="mensagem" maxlength="2000" placeholder="Escreva uma mensagem..." required></textarea>
                <button type="submit" name="enviar_mensagem">Enviar mensagem</button>
            </form>

                <div class="chat">
                <?php if (!$mensagens): ?>
                    <p class="empty">Ainda não há mensagens. Seja a primeira pessoa a conversar!</p>
                <?php else: ?>
                    <?php foreach ($mensagens as $mensagem): ?>
                        <article class="fala">
                            <div class="fala-cabecalho">
                                <span class="fala-nome"><?php echo htmlspecialchars($mensagem['nome']); ?></span>
                                <span class="fala-hora"><?php echo htmlspecialchars(date('d/m/Y H:i', strtotime($mensagem['criado_em']))); ?></span>
                            </div>
                            <p class="fala-texto"><?php echo htmlspecialchars($mensagem['mensagem']); ?></p>
                        </article>
                    <?php endforeach; ?>
                <?php endif; ?>
                </div>
            </section>

            <section class="produtos-bloco" id="catalogo">
                <h2 class="bloco-titulo">Catálogo</h2>
                <?php if (empty($produtos)): ?>
                    <p class="empty">Nenhum produto cadastrado ainda.</p>
                <?php else: ?>
                    <div class="grid">
                        <?php foreach ($produtos as $produto): ?>
                            <div class="card">
                                <?php
                                $imagem = !empty($produto['imagem']) ? 'uploads/' . $produto['imagem'] : 'logo.png';
                                ?>
                                <img src="<?php echo htmlspecialchars($imagem); ?>" alt="<?php echo htmlspecialchars($produto['nome']); ?>">
                                <div class="nome"><?php echo htmlspecialchars($produto['nome']); ?></div>
                                <div class="categoria"><?php echo htmlspecialchars($produto['categoria']); ?></div>
                                <div class="preco">R$ <?php echo htmlspecialchars($produto['preco']); ?></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                <a class="btn" href="painel.php">Voltar para o painel</a>
            </section>
        </div>
    </div>
</body>
</html>
