<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrinho | Unistore</title>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@500;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; }
        body { margin: 0; min-height: 100vh; display: grid; place-items: center; padding: 24px; background: #fff7fb; color: #8b3a62; font-family: 'Poppins', sans-serif; }
        .pagina { width: min(620px, 100%); padding: 42px 30px; border: 1px solid #f8c8dc; border-radius: 22px; background: #fff; box-shadow: 0 10px 25px rgba(139, 58, 98, .14); text-align: center; }
        .logo { width: 130px; height: 130px; object-fit: contain; }
        h1 { margin: 8px 0 10px; font-family: 'Cinzel', serif; }
        p { color: #6a4251; }
        .acoes { display: flex; justify-content: center; gap: 12px; flex-wrap: wrap; margin-top: 28px; }
        a { padding: 12px 20px; border-radius: 24px; text-decoration: none; font-weight: 600; }
        .principal { color: #fff; background: linear-gradient(135deg, #ff4fa3, #ff85c2, #ffd6a5); }
        .secundario { color: #8b3a62; background: #fce4ef; }
    </style>
</head>
<body>
    <main class="pagina">
        <img class="logo" src="logo.png" alt="Logo Unistore">
        <h1>Seu carrinho</h1>
        <p>O carrinho está pronto para receber os produtos. A função de adicionar itens será implementada aqui.</p>
        <div class="acoes">
            <a class="principal" href="produtos.php">Ver produtos</a>
            <a class="secundario" href="inicio.php">Voltar ao início</a>
        </div>
    </main>
</body>
</html>
