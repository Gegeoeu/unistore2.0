<?php
session_start();

if (!isset($_SESSION['vendedor_id'])) {
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel</title>
    <style>
        * { box-sizing: border-box; font-family: 'Segoe UI', sans-serif; }
        body {
            margin: 0;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: linear-gradient(135deg, #ffe6f2, #ffd6eb);
            color: #8b3a62;
        }
        .container {
            width: min(700px, 90vw);
            background: #fff;
            border-radius: 20px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
            padding: 40px 30px;
            text-align: center;
        }
        h1 { margin-bottom: 12px; }
        p { margin: 0 0 25px; color: #6a4251; }
        .actions {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 12px;
        }
        .btn {
            display: inline-block;
            padding: 12px 20px;
            border-radius: 999px;
            text-decoration: none;
            font-weight: bold;
            background: #d63384;
            color: #fff;
        }
        .btn.secondary {
            background: #fce4ef;
            color: #8b3a62;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Bem-vindo(a), <?php echo htmlspecialchars($_SESSION['vendedor_nome'] ?? 'Usuário'); ?>!</h1>
        <p>Escolha o que deseja fazer na Unistore.</p>

        <div class="actions">
            <a class="btn" href="cadprod.php">Vender</a>
            <a class="btn secondary" href="produtos.php">Ver produtos</a>
        </div>
    </div>
</body>
</html>
