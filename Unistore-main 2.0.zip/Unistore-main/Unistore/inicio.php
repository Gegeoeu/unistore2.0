<!DOCTYPE html>
<html lang="pt-br">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Unistore</title>

<!-- FONTES -->
<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@500;700&family=Poppins:wght@300;400;500&display=swap" rel="stylesheet">


</head>
<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@500;700&family=Poppins:wght@300;400;500&family=Playfair+Display:wght@500;700&display=swap" rel="stylesheet">

<body>

<header>

<div class="logo">
    <img src="logo.png" alt="Logo Unistore" class="logo-img">Unistore</div>

<nav>
    <a href="#sobre">SOBRE NÓS</a>
    <a href="#produtos">PRODUTOS</a>
</nav>

<div class="buttons">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">

    <a href="login.php" class="btn btn-login">
        <i class="ti ti-user"></i> Login
    </a>

    <a href="listarprod.php" class="btn btn-register">
        Criar Conta
    </a>
</div>

</header>

<section class="hero">

    <div class="hero-content">

    <h1>UNISTORE</h1>

    <a href="listarprod.php" class="hero-btn">
        ✨ Criar conta
    </a>

</div>

</section>

</section>

<section class="topicos" id="sobre">

    <h2>POR QUE USAR A UNISTORE?</h2>

    <div class="cards">

        <div class="card">
            <h3>🛍 Produtos</h3>
            <p>Descubra itens mágicos e exclusivos.</p>
        </div>

        <div class="card">
            <h3>🔥 Promoções</h3>
            <p>Aproveite descontos encantadores.</p>
        </div>

        <div class="card">
            <h3>🌙 Comunidade</h3>
            <p>Conheça aventureiros da Unistore.</p>
        </div>

        <div class="card">
            <h3>📦 Pedidos</h3>
            <p>Acompanhe suas compras facilmente.</p>
        </div>

    </div>

</section>

<!-- PRODUTOS -->
<section class="produtos" id="produtos">

    <h2>EXPLORE A MAGIA</h2>

    <p class="subtitulo">
        Navegue por nossos produtos 👇
    </p>

    <div class="produtos-container">

        <!-- PRODUTO 1 -->
        <div class="produto-card">

            <div class="produto-img">
                <img src="produto1.jpeg" alt="Produto 1">
            </div>

            <div class="produto-info">

                <h3>Escova Floral Encantada</h3>

                <p>Escova de madeira pintada à mão com flores delicadas e detalhes inspirados em contos de fadas.</p>

                <div class="preco">R$ 25,00</div>

                <a href="login.php" class="btn-produto">
                    Ver produto
                </a>

            </div>

        </div>

        <!-- PRODUTO 2 -->
        <div class="produto-card">

            <div class="produto-img">
                <img src="produto2.jpeg" alt="Produto 2">
            </div>

            <div class="produto-info">

                <h3>Porta-Joias de cerâmica</h3>

                <p>Pratinho artesanal em tons de rosa, perfeito para guardar anéis, brincos e pequenos acessórios.</p>

                <div class="preco">R$ 95,26</div>

                <a href="login.php" class="btn-produto">
                    Ver produto
                </a>

            </div>

        </div>

        <!-- PRODUTO 3 -->
        <div class="produto-card">

            <div class="produto-img">
                <img src="produto3.jpeg" alt="Produto 3">
            </div>

            <div class="produto-info">

                <h3>Chaveiro Sol Mágico</h3>

                <p>Chaveiro artesanal em formato de sol, ideal para bolsas, mochilas e chaves.</p>

                <div class="preco">R$ 15,00</div>

                <a href="login.php" class="btn-produto">
                    Ver produto
                </a>

            </div>

        </div>

        <!-- PRODUTO 4 -->
        <div class="produto-card">

            <div class="produto-img">
                <img src="produto4.jpeg" alt="Produto 4">
            </div>

            <div class="produto-info">

                <h3>Porta acessórios de cogumelo</h3>

                <p>Organizador de joias decorado com cogumelos encantados, unindo praticidade e fantasia.</p>

                <div class="preco">R$ 86,45</div>

                <a href="login.php" class="btn-produto">
                    Ver produto
                </a>

            </div>

        </div>

    </div>

    <!-- BOTÃO VER MAIS -->
<div class="ver-mais-container">

    <a href="login.php" class="btn-ver-mais">
        ✨ VER MAIS
    </a>

</div>

</section>

<footer>
    <img src="logo.png" alt="Logo Unistore" class="footer-logo">
</footer>

</body>
</html>