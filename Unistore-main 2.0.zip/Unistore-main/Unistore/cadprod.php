<?php
include "conexao.php";

$mensagem = "";

if (isset($_POST['inserir'])) {

    $nome        = trim($_POST['nome']);
    $categoria   = trim($_POST['categoria']);
    $preco       = trim($_POST['preco']);
    $erro        = false;
    $nomeImagem  = "";

    // Validações
    if (empty($nome)) {
        $mensagem .= "<p class='erro'>O nome do produto é obrigatório.</p>";
        $erro = true;
    }

    if (empty($categoria)) {
        $mensagem .= "<p class='erro'>Selecione uma categoria.</p>";
        $erro = true;
    }

    if (empty($preco)) {
        $mensagem .= "<p class='erro'>O preço é obrigatório.</p>";
        $erro = true;
    }

    // Tratamento da imagem (opcional - só valida se o usuário enviou algo)
    if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] === UPLOAD_ERR_OK) {

        $extensoesPermitidas = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        $extensao = strtolower(pathinfo($_FILES['imagem']['name'], PATHINFO_EXTENSION));

        if (!in_array($extensao, $extensoesPermitidas)) {
            $mensagem .= "<p class='erro'>Formato de imagem inválido. Use JPG, PNG, GIF ou WEBP.</p>";
            $erro = true;
        } else {
            // Gera um nome único pra evitar sobrescrever arquivos
            $nomeImagem = uniqid('produto_', true) . '.' . $extensao;
            $caminhoDestino = __DIR__ . '/uploads/' . $nomeImagem;

            if (!move_uploaded_file($_FILES['imagem']['tmp_name'], $caminhoDestino)) {
                $mensagem .= "<p class='erro'>Erro ao salvar a imagem.</p>";
                $erro = true;
            }
        }
    }

    // Se não houver erro, insere no banco usando prepared statement
    if (!$erro) {

        $sql  = "INSERT INTO produtos (nome, categoria, preco, imagem) VALUES (?, ?, ?, ?)";
        $stmt = $conexao->prepare($sql);

        if ($stmt) {
            $stmt->bind_param("ssss", $nome, $categoria, $preco, $nomeImagem);

            if ($stmt->execute()) {
                $mensagem = "<p class='sucesso'>✓ Produto cadastrado com sucesso!</p>";
            } else {
                $mensagem = "<p class='erro'>Erro ao cadastrar: " . $stmt->error . "</p>";
            }
            $stmt->close();
        } else {
            $mensagem = "<p class='erro'>Erro ao preparar a consulta: " . $conexao->error . "</p>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Cadastro de Produto</title>

<style>
</style>
</head>
<body>
<div class="container">
    <div class="card">
        <div class="logo-circle">🛍️</div>
        <h2>Novo Produto</h2>
        <p class="subtitle">Preencha os dados para cadastrar</p>

        <?php echo $mensagem; ?>

        <form method="post" enctype="multipart/form-data">

            <label>Nome do Produto</label>
            <input name="nome" type="text" placeholder="Ex: Camiseta Floral" required
                    value="<?php echo htmlspecialchars($_POST['nome'] ?? ''); ?>">

            <label>Categoria</label>
            <select name="categoria" required>
                <option value="">Selecione...</option>
                <option value="Roupas"      <?php echo (($_POST['categoria'] ?? '') === 'Roupas')      ? 'selected' : ''; ?>>Roupas</option>
                <option value="Calçados"    <?php echo (($_POST['categoria'] ?? '') === 'Calçados')    ? 'selected' : ''; ?>>Calçados</option>
                <option value="Acessórios"  <?php echo (($_POST['categoria'] ?? '') === 'Acessórios')  ? 'selected' : ''; ?>>Acessórios</option>
                <option value="Eletrônicos" <?php echo (($_POST['categoria'] ?? '') === 'Eletrônicos') ? 'selected' : ''; ?>>Eletrônicos</option>
                <option value="Outros"      <?php echo (($_POST['categoria'] ?? '') === 'Outros')      ? 'selected' : ''; ?>>Outros</option>
            </select>

            <div class="row">
                <div class="field">
                    <label>Preço</label>
                    <input name="preco" type="text" required
                            value="<?php echo htmlspecialchars($_POST['preco'] ?? ''); ?>">
                </div>
            </div>

            <label>Imagem do Produto</label>
            <input name="imagem" type="file" accept="image/*">

            <button type="submit" name="inserir">Cadastrar Produto</button>
        </form>

        <p class="footer-link">Ver todos os produtos? <a href="produtos.php">Listar</a></p>
    </div>
</div>

</body>
</html>